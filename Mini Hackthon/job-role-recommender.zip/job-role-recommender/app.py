import streamlit as st
from rag_engine import get_recommendation
from utils.parser import extract_career_intent

st.set_page_config(page_title="🎯 Job Role Recommender", layout="centered")

st.title("💼 AI Job Role Recommender")
st.write("Upload your cover letter or statement. We’ll recommend better-matching job roles based on your career intent.")

uploaded_file = st.file_uploader("📄 Upload your .txt file", type=["txt", "md"])

if uploaded_file:
    raw_text = uploaded_file.read().decode("utf-8")
    st.text_area("🔍 Uploaded Text:", raw_text, height=200)

    career_intent = extract_career_intent(raw_text)
    st.success(f"✅ Detected Career Intent: {career_intent}")

    if st.button("🔎 Recommend Roles"):
        with st.spinner("Analyzing..."):
            result = get_recommendation(career_intent)
            st.subheader("🎓 Suggested Roles")
            st.write(result)
