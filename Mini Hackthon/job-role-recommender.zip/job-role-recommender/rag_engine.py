import os
import google.generativeai as genai
from dotenv import load_dotenv
from langchain.vectorstores import FAISS
from langchain.embeddings import HuggingFaceEmbeddings
from langchain.docstore.document import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter

load_dotenv()
genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))

from langchain.embeddings import HuggingFaceEmbeddings

embedder = HuggingFaceEmbeddings(
    model_name="sentence-transformers/all-MiniLM-L6-v2",
    model_kwargs={"device": "cpu"}  # force to use CPU
)

def load_documents(path="data/roles_knowledgebase.txt"):
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
    return [Document(page_content=line.strip()) for line in lines if line.strip()]

def get_vector_store():
    docs = load_documents()
    splitter = RecursiveCharacterTextSplitter(chunk_size=300, chunk_overlap=50)
    split_docs = splitter.split_documents(docs)

    embedder = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")
    db = FAISS.from_documents(split_docs, embedder)
    return db

def retrieve_context(query, db, k=4):
    return db.similarity_search(query, k=k)

def generate_response_with_gemini(prompt):
    model = genai.GenerativeModel("gemini-1.5-flash")
    response = model.generate_content(prompt)
    return response.text

def get_recommendation(intent):
    db = get_vector_store()
    docs = retrieve_context(intent, db)
    context = "\n".join([doc.page_content for doc in docs])

    final_prompt = f"""
You are a career guidance assistant.
Based on the candidate's career intent:
"{intent}"

And the following role definitions:
{context}

Suggest 2-3 best-fitting job roles. For each, explain why it matches.
"""
    return generate_response_with_gemini(final_prompt)
