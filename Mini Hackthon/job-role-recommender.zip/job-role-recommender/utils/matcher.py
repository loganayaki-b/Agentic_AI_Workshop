def construct_prompt(intent):
    return f"""
The candidate expressed: "{intent}"

Based on this career intent, suggest 2-3 job roles from your knowledge that align well.
Justify each suggestion briefly.
"""
