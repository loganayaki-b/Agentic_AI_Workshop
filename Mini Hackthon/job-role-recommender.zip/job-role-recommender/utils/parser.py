def extract_career_intent(text):
    keywords = ["looking to", "interested in", "aspire to", "want to", "seeking", "aim to"]
    for line in text.splitlines():
        if any(k in line.lower() for k in keywords):
            return line.strip()
    return "No clear career intent found."
